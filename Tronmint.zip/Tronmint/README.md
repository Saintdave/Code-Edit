# tronwage
TronWage is a decentralized community funded project which is powered by the Tron Blockchain.
