var Tronwage = artifacts.require("./Tronwage.sol");

module.exports = function(deployer) {
  deployer.deploy(Tronwage);
};
